tracks can be made out of 1000x1000 png images
	white- off the track
	black- on track
	gray- finish
	blue- start

generate policy for part 1 of the assignment with <python skrrt.py>

generate policy for part 2 of the assignment with <python skrrtPart2.py>

generate convergence graphs with <generateGraph1.py>

plot example paths using policy pi generated in skrrt/skrrtPart2 with <viewPathFromPi.py>
	adjust epsilon on line 25
	use pretrained policy by uncommenting lines 19 and 20, 
			set name of policy to output of skrrt