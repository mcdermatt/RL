Generate trial data using <ex2_5MC.py> modifying line 21 to change step size parameter for WA

Plot trial data using <generateGraph2.py>